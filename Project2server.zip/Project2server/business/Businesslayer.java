package business;
import data.*;
import java.util.Date;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;
import org.xml.sax.InputSource;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.util.*;
import data.DBSingleton;
import components.data.*;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


@SuppressWarnings("unchecked")
public class Businesslayer{
DBSingleton dbSingleton;
String patientId="";
String phlebId="";
String pscId="";
String physicianId="";
//----------------------------------------------------------------------------------------------
//to initialize the database
public String initialize()
{
   dbSingleton = DBSingleton.getInstance();		  
       dbSingleton.db.initialLoad("LAMS");
      return "Database Initialized";
}
//------------------------------------------------------------------------------------------------
//to get all the appointment details in xml style string format.

public String getAllAppointments()
{
dbSingleton = DBSingleton.getInstance();
List<Object> objs4 = dbSingleton.db.getData("Appointment", "");
//System.out.println(objs);
String xml4="";
StringWriter writer4=new StringWriter();

String patientid="";
Patient patient = null;
Phlebotomist phleb = null;
PSC psc = null;
xml4="<AppointmentList>";
 for (Object obj : objs4){
         Diagnosis diagnosis=null;
         Appointment appointment=null;
         LabTest labtest=null;
           // System.out.println(obj);
           patient = ((Appointment)obj).getPatientid();
            patientid = (((Appointment)obj).getPatientid()).toString();
           // System.out.println(patientid);
          
            phleb = ((Appointment)obj).getPhlebid();
            psc = ((Appointment)obj).getPscid();
            List<AppointmentLabTest> apts=((Appointment)obj).getAppointmentLabTestCollection();
                   xml4+="<appointment date=\""+((Appointment)obj).getApptdate()+"\" id=\""+((Appointment)obj).getId()+"\" time=\""+((Appointment)obj).getAppttime()+"\"><patient id=\""+((Patient)patient).getId()+"\"><name>"+((Patient)patient).getName()+"</name><adress>"+((Patient)patient).getAddress()+"</adress><insurance>"+((Patient)patient).getInsurance()+"</insurance><dob>"+((Patient)patient).getDateofbirth()+"</dob></patient><phlebotomist id=\""+((Phlebotomist)phleb).getId()+"\"><name>"+((Phlebotomist)phleb).getName()+"</name></phlebotomist><psc id=\""+((PSC)psc).getId()+"\"><name>"+((PSC)psc).getName()+"</name></psc><allLabTests>";
                    for (AppointmentLabTest a : apts){
                    diagnosis=((AppointmentLabTest)a).getDiagnosis();
                    appointment=((AppointmentLabTest)a).getAppointment();
                    labtest=((AppointmentLabTest)a).getLabTest();
   xml4+="<appointmentLabTest appointmentId=\""+((Appointment)obj).getId()+"\" dxcode=\""+((Diagnosis)diagnosis).getCode()+"\" labTestId=\""+((LabTest)labtest).getId()+"\"/>";
                          
                                                  } 
                                                  xml4+="</allLabTests></appointment>";                                              
                                                     }
                                                  xml4+="</AppointmentList>";
                                                  
                                               
try
{
 DocumentBuilderFactory dbFactory4=DocumentBuilderFactory.newInstance();
 DocumentBuilder dbBuilder4=dbFactory4.newDocumentBuilder();
 Document doc4=dbBuilder4.parse(new InputSource(new StringReader(xml4)));
 TransformerFactory transformerFactory4=TransformerFactory.newInstance();
       Transformer transformer4=transformerFactory4.newTransformer();
       transformer4.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
        transformer4.setOutputProperty(OutputKeys.INDENT,"yes");
         transformer4.setOutputProperty(OutputKeys.STANDALONE,"yes");
         DOMSource source4=new DOMSource(doc4);
         StreamResult result4=new StreamResult(writer4);
         transformer4.transform(source4,result4);
      System.out.println("\n all appointments xml in string format is:\n"+writer4.toString());
}
catch(Exception ex)
      {
        StringWriter errors = new StringWriter();
         ex.printStackTrace(new PrintWriter(errors));
         System.out.println(errors.toString());
         xml4= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><error>Bad appointment</error>";
          return xml4;
         }
   return writer4.toString(); 
} 
//--------------------------------------------------------------------------------------------------
//to get a particular appointment detail in xml style string format given the appt id.

public String getAppointment(String aid)
{
String id=aid;
dbSingleton = DBSingleton.getInstance();
List<Object> objs5 = dbSingleton.db.getData("Appointment","id='"+id+"'");
                 StringWriter writer5=new StringWriter();
        String patientid="";
        Patient patient = null;
        Phlebotomist phleb = null;
        PSC psc = null;
       for (Object obj : objs5){
         System.out.println(((Appointment)obj).getId());
         if(id.equals(((Appointment)obj).getId()))
         {
          String xml5="";

         Diagnosis diagnosis=null;
         Appointment appointment=null;
         LabTest labtest=null;
           // System.out.println(obj);
            patient = ((Appointment)obj).getPatientid();
            patientid = (((Appointment)obj).getPatientid()).toString();
           // System.out.println(patientid);
            phleb = ((Appointment)obj).getPhlebid();
            psc = ((Appointment)obj).getPscid();
            List<AppointmentLabTest> apts=((Appointment)obj).getAppointmentLabTestCollection();
      xml5="<AppointmentList><appointment date=\""+((Appointment)obj).getApptdate()+"\" id=\""+id+"\" time=\""+((Appointment)obj).getAppttime()+"\"><patient id=\""+((Patient)patient).getId()+"\"><name>"+((Patient)patient).getName()+"</name><adress>"+((Patient)patient).getAddress()+"</adress><insurance>"+((Patient)patient).getInsurance()+"</insurance><dob>"+((Patient)patient).getDateofbirth()+"</dob></patient><phlebotomist id=\""+((Phlebotomist)phleb).getId()+"\"><name>"+((Phlebotomist)phleb).getName()+"</name></phlebotomist><psc id=\""+((PSC)psc).getId()+"\"><name>"+((PSC)psc).getName()+"</name></psc><allLabTests>";
                    for (AppointmentLabTest a : apts){
                    diagnosis=((AppointmentLabTest)a).getDiagnosis();
                    appointment=((AppointmentLabTest)a).getAppointment();
                    labtest=((AppointmentLabTest)a).getLabTest();

      xml5+="<appointmentLabTest appointmentId=\""+((Appointment)obj).getId()+"\" dxcode=\""+((Diagnosis)diagnosis).getCode()+"\" labTestId=\""+((LabTest)labtest).getId()+"\"/>";
                          
                                                  }
                                                  xml5+="</allLabTests></appointment></AppointmentList> ";
                                                                                                                                                
  try
{
 DocumentBuilderFactory dbFactory5=DocumentBuilderFactory.newInstance();
 DocumentBuilder dbBuilder5=dbFactory5.newDocumentBuilder();
 Document doc5=dbBuilder5.parse(new InputSource(new StringReader(xml5)));
 TransformerFactory transformerFactory5=TransformerFactory.newInstance();
       Transformer transformer5=transformerFactory5.newTransformer();
       transformer5.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
        transformer5.setOutputProperty(OutputKeys.INDENT,"yes");
         transformer5.setOutputProperty(OutputKeys.STANDALONE,"yes");
         DOMSource source5=new DOMSource(doc5);
         StreamResult result5=new StreamResult(writer5);
         transformer5.transform(source5,result5);
          System.out.println("\n xml data of appointment for the id entered in string format is:\n"+writer5.toString());
}
catch(Exception ex)
      {
        StringWriter errors = new StringWriter();
         ex.printStackTrace(new PrintWriter(errors));
         System.out.println(errors.toString());
          xml5= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><error>app not found</error>";
                          
          return xml5;

         }
         

 return writer5.toString();
 
      } 
      else 
      {
      
      return "<error>appt not found</error>";
      }                                      
       
         }
         return "<error>bad appointment</error>";

         
 
}
//----------------------------------------------------------------------------------------------- 
//to get all patient details in xml style string format 
public String getAllPatients()
{

dbSingleton = DBSingleton.getInstance();
List<Object> objs2 = dbSingleton.db.getData("Patient", "");
//System.out.println(objs);
String xml2="";
StringWriter writer2=new StringWriter();
String address=""; 
List<Appointment>	appointmentCollection;
Date dateofbirth=null;
Date date=null;
Date time=null;
String pid ="";
String apid ="";
char insurance; 
String name=""; 
Physician physician =null;
        xml2="<PatientList>";
         for (Object obj : objs2){
             // System.out.println(obj);
           physician = ((Patient)obj).getPhysician();
            pid = (((Patient)obj).getId()).toString();
           // System.out.println(pid);
           appointmentCollection = ((Patient)obj).getAppointmentCollection() ;
                       address = ((Patient)obj).getAddress();
           name=((Patient)obj).getName();
           dateofbirth=((Patient)obj).getDateofbirth();
           insurance = ((Patient)obj).getInsurance();
                              xml2+="<patient name=\""+((Patient)obj).getName()+"\" id=\""+((Patient)obj).getId()+"\" address=\""+((Patient)obj).getAddress()+"\" insurance=\""+((Patient)obj).getInsurance()+"\" dob=\""+((Patient)obj).getDateofbirth()+"\"><physician id=\""+((Physician)physician).getId()+"\" name=\""+((Physician)physician).getName()+"\"/><allappointments>";
                    for (Appointment a : appointmentCollection){
                    apid=((Appointment)a).getId();
                    date=((Appointment)a).getApptdate();
                    time=((Appointment)a).getAppttime();
 xml2+="<appointment appointmentId=\""+((Appointment)a).getId()+"\" date=\""+((Appointment)a).getApptdate()+"\" time=\""+((Appointment)a).getAppttime()+"\">";
                          xml2+="</appointment>";
                                                  }                                                  
                                                  xml2+="</allappointments></patient>";
                                                  }
                                                  xml2+="</PatientList>";
try
{
 DocumentBuilderFactory dbFactory2=DocumentBuilderFactory.newInstance();
 DocumentBuilder dbBuilder2=dbFactory2.newDocumentBuilder();
 Document doc2=dbBuilder2.parse(new InputSource(new StringReader(xml2)));
 TransformerFactory transformerFactory2=TransformerFactory.newInstance();
       Transformer transformer2=transformerFactory2.newTransformer();
       transformer2.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
        transformer2.setOutputProperty(OutputKeys.INDENT,"yes");
         transformer2.setOutputProperty(OutputKeys.STANDALONE,"yes");
         DOMSource source2=new DOMSource(doc2);
        StreamResult result=new StreamResult(writer2);
         transformer2.transform(source2,result);
          System.out.println("\n all patients xml in string format is:\n"+writer2.toString());
}
catch(Exception ex)
      {
        StringWriter errors = new StringWriter();
         ex.printStackTrace(new PrintWriter(errors));
         System.out.println(errors.toString());
         xml2= "<?xml version='1.0' encoding='UTF-8' standalone='no'?>Bad appointment</error>";
          return xml2;

         }
            return writer2.toString(); 
}
//----------------------------------------------------------------------------------------------- 
//to get a particular patient detail in xml style string format given the patient id.
public String getPatient(String id)
{
String pid=id;
dbSingleton = DBSingleton.getInstance();
List<Object> objs6 = dbSingleton.db.getData("Patient", "id='"+pid+"'");
//System.out.println(objs);

StringWriter writer6=new StringWriter();
String address=""; 
List<Appointment>	appointmentCollection;
Date dateofbirth=null;
Date date=null;
Date time=null;

String apid ="";
char insurance; 
String name=""; 
Physician physician =null;
                for (Object obj : objs6){
                    // System.out.println(obj);
         if(pid.equals(((Patient)obj).getId()))
         {
         String xml6="";
           physician = ((Patient)obj).getPhysician();
            pid = (((Patient)obj).getId()).toString();
           // System.out.println(patientid);
           appointmentCollection = ((Patient)obj).getAppointmentCollection() ;
           address = ((Patient)obj).getAddress();
           name=((Patient)obj).getName();
           dateofbirth=((Patient)obj).getDateofbirth();
           insurance = ((Patient)obj).getInsurance();
xml6+="<patient name=\""+((Patient)obj).getName()+"\" id=\""+((Patient)obj).getId()+"\" address=\""+((Patient)obj).getAddress()+"\" insurance=\""+((Patient)obj).getInsurance()+"\" dob=\""+((Patient)obj).getDateofbirth()+"\"><physician id=\""+((Physician)physician).getId()+"\" name=\""+((Physician)physician).getName()+"\"/><allappointments>";
                    for (Appointment a : appointmentCollection){
                    apid=((Appointment)a).getId();
                    date=((Appointment)a).getApptdate();
                    time=((Appointment)a).getAppttime();
xml6+="<appointment appointmentId=\""+((Appointment)a).getId()+"\" date=\""+((Appointment)a).getApptdate()+"\" time=\""+((Appointment)a).getAppttime()+"\">";
xml6+="</appointment>";
            }                                                  
                                                  xml6+="</allappointments></patient>";
try
{
 DocumentBuilderFactory dbFactory6=DocumentBuilderFactory.newInstance();
 DocumentBuilder dbBuilder6=dbFactory6.newDocumentBuilder();
 Document doc6=dbBuilder6.parse(new InputSource(new StringReader(xml6)));
 TransformerFactory transformerFactory6=TransformerFactory.newInstance();
       Transformer transformer6=transformerFactory6.newTransformer();
       transformer6.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
        transformer6.setOutputProperty(OutputKeys.INDENT,"yes");
         transformer6.setOutputProperty(OutputKeys.STANDALONE,"yes");
         DOMSource source6=new DOMSource(doc6);
         StreamResult result6=new StreamResult(writer6);
          transformer6.transform(source6,result6);
          System.out.println("\n For this id, patient xml data in string format is:\n"+writer6.toString());
}
catch(Exception ex)
      {
        StringWriter errors = new StringWriter();
         ex.printStackTrace(new PrintWriter(errors));
         System.out.println(errors.toString());
         xml6= "<?xml version='1.0' encoding='UTF-8' standalone='no'?>Bad appointment</error>";
          return xml6;
         }
return writer6.toString(); 
 } 
      else 
      {
      
      return "<error>appt not found</error>";
      }                                      
       
         }
         return "<error>bad patient</error>";

} 
//-----------------------------------------------------------------------------------------------
//to add a new appointment when the appointment details are correct and phlebotomist is available
public String addAppointment(String xmlstyle)
{
dbSingleton = DBSingleton.getInstance();
java.sql.Time appttime=null;
java.sql.Date apptdate=null;

String dxcode="";
String testid="";

String date="";
String time="";

Patient p=null;
Physician ph=new Physician();
PSC ps=new PSC();
Phlebotomist pb=new Phlebotomist();
List<AppointmentLabTest> tests=new ArrayList<AppointmentLabTest>();
List<Object> objs;
List<Object> newobjs;
List<LabTest> ts=new ArrayList<LabTest>();
String apptid="";
String xml1="";
StringWriter writer1=new StringWriter();
//xmlstyle="<?xml version='1.0' encoding='utf-8' standalone='no'?><appointment><date>2017-01-02</date><time>11:00</time><patientId>210</patientId><physicianId>10</physicianId><pscId>500</pscId><phlebotomistId>100</phlebotomistId><labTests><test id='82088' dxcode='290.0' /><test id='86609' dxcode='307.3' /></labTests></appointment>";
try
{
 DocumentBuilderFactory dbFactory=DocumentBuilderFactory.newInstance();
 DocumentBuilder dbBuilder=dbFactory.newDocumentBuilder();
 Document doc=dbBuilder.parse(new InputSource(new StringReader(xmlstyle)));
 Element element=doc.getDocumentElement();
 AppointmentLabTest al=new AppointmentLabTest();
 LabTest t;
 Diagnosis d;
 System.out.println("Appointment element:"+element.getNodeName());
      NodeList nList=doc.getElementsByTagName("appointment");
       System.out.println("-------------------------------");
       for(int i=0;i<nList.getLength();i++)
       {
       Node nNode=nList.item(i);
       System.out.println("\n/CurrentElement:"+nNode.getNodeName());
       if(nNode.getNodeType()==Node.ELEMENT_NODE)
       {
       Element eElement=(Element)nNode;
       System.out.println("date:"+eElement.getElementsByTagName("date").item(0).getTextContent());
       date=eElement.getElementsByTagName("date").item(0).getTextContent();
       apptdate=java.sql.Date.valueOf(date);
       System.out.println("apptdate:"+apptdate);
       System.out.println("time:"+eElement.getElementsByTagName("time").item(0).getTextContent());
       time=eElement.getElementsByTagName("time").item(0).getTextContent();
       SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
       appttime= new java.sql.Time(formatter.parse(time).getTime());
       System.out.println("appttime:"+appttime);
       System.out.println("patientId:"+eElement.getElementsByTagName("patientId").item(0).getTextContent());
       patientId=eElement.getElementsByTagName("patientId").item(0).getTextContent();
       System.out.println("physicianId:"+eElement.getElementsByTagName("physicianId").item(0).getTextContent());
       physicianId=eElement.getElementsByTagName("physicianId").item(0).getTextContent();
       
       System.out.println("pscId:"+eElement.getElementsByTagName("pscId").item(0).getTextContent());
       pscId=eElement.getElementsByTagName("pscId").item(0).getTextContent();
       System.out.println("phlebotomistId:"+eElement.getElementsByTagName("phlebotomistId").item(0).getTextContent());
       phlebId =eElement.getElementsByTagName("phlebotomistId").item(0).getTextContent();
      
       NodeList nList1=doc.getElementsByTagName("test");
       System.out.println(nList1);
       System.out.println(nList1.getLength());
       for(int k=0;k<nList1.getLength();k++)
       {
       Node nNode1=nList1.item(k);
       System.out.println("\n/CurrentElement:"+nNode1.getNodeName());
       Element eElement1=(Element)nNode1;
       System.out.println("test id:"+eElement1.getAttribute("id"));
       testid=eElement1.getAttribute("id");
       System.out.println("test dxcode:"+eElement1.getAttribute("dxcode"));
       dxcode=eElement1.getAttribute("dxcode");
       if(checkifLabTestValid(dxcode,testid))
       {
       System.out.println("this labtest is valid");
           AppointmentLabTest test = new AppointmentLabTest(getNewApptId(),testid,dxcode);
        test.setDiagnosis((Diagnosis)dbSingleton.db.getData("Diagnosis", "code='"+dxcode+"'").get(0));
         test.setLabTest((LabTest)dbSingleton.db.getData("LabTest","id='"+testid+"'").get(0));
        tests.add(test);
       }
       else
       {
        System.out.println("labtests not valid");

        return "<?xml version='1.0' encoding='UTF-8' standalone='no'?>Bad appointment</error>";
         }
       
      }
       apptid=getNewApptId();

       NodeList test=eElement.getElementsByTagName("test");
       for(int j=0;j<test.getLength();j++)
       {
       System.out.println("test"+test.item(j).getTextContent());
       }
       System.out.println("------------------------\n\n");
       }       
       }
       TransformerFactory transformerFactory=TransformerFactory.newInstance();
       Transformer transformer=transformerFactory.newTransformer();
       transformer.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
       transformer.setOutputProperty(OutputKeys.INDENT,"yes");
       transformer.setOutputProperty(OutputKeys.STANDALONE,"yes");
       DOMSource source=new DOMSource(doc);
       StringWriter writer=new StringWriter();
       StreamResult result2=new StreamResult(writer);
       transformer.transform(source,result2);
       System.out.println("\n xml sent in string format is:\n"+writer.toString());
 if((checkifDateAndTimeValid(date,time)) && (checkifApptValid(phlebId,pscId,patientId,physicianId)))
 {
        System.out.println("All the entered appt details are valid");

        Appointment newAppt = new Appointment(getNewApptId(),java.sql.Date.valueOf(date),java.sql.Time.valueOf(time.concat(":00")));
        objs = dbSingleton.db.getData("Appointment", "");
    
        newAppt.setAppointmentLabTestCollection(tests);
        p =(Patient) ((dbSingleton.db.getData("Patient","id='"+patientId+"'")).get(0));
        newAppt.setPatientid(p);
        ph = (Physician) ((dbSingleton.db.getData("Physician", "id='"+physicianId+"'")).get(0));
        pb = (Phlebotomist) ((dbSingleton.db.getData("Phlebotomist", "id='"+phlebId+"'")).get(0));
        ps = (PSC) ((dbSingleton.db.getData("PSC", "id='"+pscId+"'")).get(0));
 
        newAppt.setPhlebid(pb);
        newAppt.setPscid(ps);
         if(checkifPhlebotomistandPSCavailable(newAppt))
         {
           boolean good = dbSingleton.db.addData(newAppt);
           System.out.println("new appt was added,"+good);
                }
         else
          {
           xml1= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><error>pheb not available at psc</error>";
           return xml1;

           }
        }
        else
        {
        xml1= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><error>appointment details not valid</error>";
        return xml1;
        }

        // Print out all appointments including the newly added one (apptId)
        System.out.println("All appointments, including newly added \n");

        newobjs = dbSingleton.db.getData("Appointment","");
        for (Object obj : newobjs){
         System.out.println(apptid + "\n");
         System.out.println(obj + "\n");
         System.out.println(((Appointment)obj).getId());
        String patientid="";
        Patient patient = null;
        Phlebotomist phleb = null;
        PSC psc = null;
         if(apptid.equals(((Appointment)obj).getId()))
         {
         Diagnosis diagnosis=null;
         Appointment appointment=null;
         LabTest labtest=null;
           // System.out.println(obj);
           patient = ((Appointment)obj).getPatientid();
            patientid = (((Appointment)obj).getPatientid()).toString();
           // System.out.println(patientid);
            phleb = ((Appointment)obj).getPhlebid();
            psc = ((Appointment)obj).getPscid();
            List<AppointmentLabTest> apts=((Appointment)obj).getAppointmentLabTestCollection();
                  xml1="<AppointmentList><appointment date=\""+((Appointment)obj).getApptdate()+"\" id=\""+apptid+"\" time=\""+((Appointment)obj).getAppttime()+"\"><patient id=\""+((Patient)patient).getId()+"\"><name>"+((Patient)patient).getName()+"</name><adress>"+((Patient)patient).getAddress()+"</adress><insurance>"+((Patient)patient).getInsurance()+"</insurance><dob>"+((Patient)patient).getDateofbirth()+"</dob></patient><phlebotomist id=\""+((Phlebotomist)phleb).getId()+"\"><name>"+((Phlebotomist)phleb).getName()+"</name></phlebotomist><psc id=\""+((PSC)psc).getId()+"\"><name>"+((PSC)psc).getName()+"</name></psc><allLabTests>";
                    for (AppointmentLabTest a : apts){
                    diagnosis=((AppointmentLabTest)a).getDiagnosis();
                    appointment=((AppointmentLabTest)a).getAppointment();
                    labtest=((AppointmentLabTest)a).getLabTest();
               xml1+="<appointmentLabTest appointmentId=\""+apptid+"\" dxcode=\""+((Diagnosis)diagnosis).getCode()+"\" labTestId=\""+((LabTest)labtest).getId()+"\"/>";
                          
                                                  }
                                                  xml1+="</allLabTests></appointment></AppointmentList> ";
                                                   }
                                             
         else
         {
                                                xml1= "<error>app not found</error>";
         }
         }
                                                                                                    
   try
   {
 DocumentBuilderFactory dbFactory1=DocumentBuilderFactory.newInstance();
 DocumentBuilder dbBuilder1=dbFactory1.newDocumentBuilder();
 Document doc1=dbBuilder1.parse(new InputSource(new StringReader(xml1)));
 TransformerFactory transformerFactory1=TransformerFactory.newInstance();
       Transformer transformer1=transformerFactory1.newTransformer();
       transformer1.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
        transformer1.setOutputProperty(OutputKeys.INDENT,"yes");
         transformer1.setOutputProperty(OutputKeys.STANDALONE,"yes");
         
         
         DOMSource source1=new DOMSource(doc1);
        
         StreamResult result1=new StreamResult(writer1);
         
          transformer1.transform(source1,result1);
          System.out.println("\n xml data of appointment for the new appt id created in string format is:\n"+writer1.toString());
   }
      catch(Exception ex)
      {
        StringWriter errors = new StringWriter();
         ex.printStackTrace(new PrintWriter(errors));
         System.out.println(errors.toString());
         xml1= "<?xml version='1.0' encoding='UTF-8' standalone='no'?>Bad appointment</error>";
          return xml1;

         }
   return writer1.toString(); 
 }
 catch(Exception ex)
       {
         StringWriter errors = new StringWriter();
          ex.printStackTrace(new PrintWriter(errors));
          System.out.println(errors.toString());
                    
          }
    xml1= "<?xml version='1.0' encoding='UTF-8' standalone='no'?>Bad appointment</error>";
          return xml1;       

}
//-------------------------------------------------------------------------------------------
//to get a new appointment id for the next appointment
public String getNewApptId(){
            List<Appointment> appts = (List<Appointment>)(List)dbSingleton.db.getData("Appointment", "");
            int length = appts.size();
            System.out.println(length);
            int id = Integer.parseInt(appts.get(length-1).getId())+10;
            System.out.println(String.valueOf(id));
            return String.valueOf(id);
        }
//----------------------------------------------------------------------------------------------        
//to check if the date and time is valid i.e within the office hours of 8 to 5         
public boolean checkifDateAndTimeValid(String date, String time){
            
            try{
            String datetime = date.concat(" " + time);
            
            System.out.println(datetime);

            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            System.out.println(sdf);

            sdf.setLenient(false);
            String apptDateString = datetime;
            System.out.println(apptDateString);
            Date apptDate = sdf.parse(apptDateString);
            System.out.println(apptDateString);

            Calendar apptDateCalendar = Calendar.getInstance();
            apptDateCalendar.setTime(apptDate);
            System.out.println(apptDateCalendar);
                
            Calendar now = Calendar.getInstance();
            if(apptDateCalendar.before(now)) {  
                //Past Appointments i.e. having date before now (current time) is not considered valid 
                                return false;
            }else{
                if(apptDateCalendar.get(Calendar.HOUR_OF_DAY) < 8 || apptDateCalendar.get(Calendar.HOUR_OF_DAY) > 16 ){
                    //invalid hours of the day when appointments can't be made  
                    return false;
                }
                if(apptDateCalendar.get(Calendar.HOUR_OF_DAY)==16 && apptDateCalendar.get(Calendar.MINUTE)>45){
                       //any appointment after 4.45PM is invalid becuase it ends at 5 and phleb needs min 15 min minimum for one appt
                        return false;
                }
            }
            
            }catch(ParseException e){
                System.out.println("Invalid date format");
                return false;
            }
            System.out.println("Date is valid");
            return true;
        }
//---------------------------------------------------------------------------------------------        
public boolean checkifApptValid(String phlebId, String pscId, String patientId, String physicianId){       
            List<Phlebotomist> phlebs = (List<Phlebotomist>) (List)dbSingleton.db.getData("Phlebotomist", "");
            List<Physician> physicians = (List<Physician>) (List)dbSingleton.db.getData("Physician", "");
            List<Patient> patients = (List<Patient>) (List)dbSingleton.db.getData("Patient", "");
            List<PSC> pscs = (List<PSC>) (List)dbSingleton.db.getData("PSC", "");
            boolean valid=false;
            boolean phleblistcontainsid=false;
            boolean patientlistcontainsid=false;
            boolean physlistcontainsid=false;
            boolean psclistcontainsid=false;


             
                         System.out.println("checking for valid apptmnt details");
              for (Phlebotomist object : phlebs) {
               if (object.getId().equals(phlebId)) {
                       phleblistcontainsid= true;
                  }
               }
               System.out.println("phleb "+phleblistcontainsid);
               for (Patient object : patients) {
               if (object.getId().equals(patientId)) {
                       patientlistcontainsid= true;
                  }
               }
               System.out.println("patient "+patientlistcontainsid);
               
               for (Physician object : physicians) {
               if (object.getId().equals(physicianId)) {
                       physlistcontainsid= true;
                  }
               }
               System.out.println("physician "+physlistcontainsid);
               
               for (PSC object : pscs) {
               if (object.getId().equals(pscId)) {
                       psclistcontainsid= true;
                  }
               }
               System.out.println("psc "+psclistcontainsid);

            try{
               
                  if(phleblistcontainsid && patientlistcontainsid && physlistcontainsid && psclistcontainsid)
                  {
                    //in the new appt valid ids entered for each of these items
                     System.out.println("valid ids entered for all");

                    valid =true;
                    }                 
            }
            catch(IndexOutOfBoundsException ex){
                valid= false;
            } 
             System.out.println("valid,"+valid);
            return valid;
        }
//----------------------------------------------------------------------------------------------
        
// to check if the lab test data is valid        
public boolean checkifLabTestValid(String dxcode,String testid){
boolean diaglistcontainsid=false;
boolean labtestlistcontainsid=false;
boolean status=false;
            try{
            System.out.println(dxcode);
             System.out.println(testid);

            List<LabTest> labtests = (List<LabTest>) (List)dbSingleton.db.getData("LabTest", "");
            System.out.println(labtests);
             for (LabTest object : labtests) {
             System.out.println(object.getId());
               if (object.getId().equals(testid)) {
                       labtestlistcontainsid= true;
                  }
               }

                                    
           
                         List<Diagnosis> diags = (List<Diagnosis>) (List)dbSingleton.db.getData("Diagnosis", "");
       System.out.println(diags);
        for (Diagnosis object : diags) {
        System.out.println(object.getCode());

                       if (object.getCode().equals(dxcode)) {
                      diaglistcontainsid= true;
                  }
               }
                                    if(diaglistcontainsid && labtestlistcontainsid)
                 {
                 System.out.println("Lab test data is valid");
                 status=true;
                 }
                  
                return status;
                
                
                
            }catch(ArrayIndexOutOfBoundsException ex){
                //Lab test data is invalid
                return false;
            }          
        }
//---------------------------------------------------------------------------------------------        
// to check if the phlebotomist can be available at the required PSC on the appt time        
public boolean checkifPhlebotomistandPSCavailable(Appointment appt){
            List<Appointment> apptsforSamePhlebo = (List<Appointment>)(List)dbSingleton.db.getData("Appointment", "phlebid='" + appt.getPhlebid().getId()+"'");
             System.out.println(apptsforSamePhlebo);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            sdf.setLenient(false);
            boolean correct=true;
            
            try{
                if(!apptsforSamePhlebo.isEmpty()){ 
                //for appointments with the same phlebotomist check the gap between the 2 appointments the new and the existing ones

                    for(Appointment appointment : apptsforSamePhlebo){ 
                            String currApptDateTime = appointment.getApptdate().toString() + " " + appointment.getAppttime().toString();
                            Date currDate = sdf.parse(currApptDateTime);
                            Calendar currCalDate = Calendar.getInstance();
                            currCalDate.setTime(currDate);
                            System.out.println(currDate);
                            String newApptDateTime = appt.getApptdate().toString() + " " + appt.getAppttime().toString();
                            Date newDate = sdf.parse(newApptDateTime);
                            Calendar newCalDate = Calendar.getInstance();
                            newCalDate.setTime(newDate);
                            System.out.println(newDate);
                            System.out.println(currCalDate.getTimeInMillis()/60000);
                            long currCalDateInMin=(currCalDate.getTimeInMillis()/60000);
                            long newCalDateInMin=(newCalDate.getTimeInMillis()/60000);
                            long currenttime=currCalDate.getTimeInMillis();
                            System.out.println(newCalDate.getTimeInMillis()/60000);
                            long differenceInMinutes = currCalDateInMin - newCalDateInMin;
                            System.out.println(differenceInMinutes);
                            if(!appointment.getPscid().equals(appt.getPscid())){ //when different PSCs then difference between the appointment start times of the 2 appointments should be more than 45 minutes    
                                if((int)differenceInMinutes > 45 || (int)differenceInMinutes<-45){
                                    correct= true; 
                                }else{
                                    //Phlebotomist is not available at this PSC


                                    correct= false;
                                }
                                
                            }else{ //when same PSC then difference between the appointment start times of the 2 appointments should be more than 15 minutes
                                if((int)differenceInMinutes > 15 || (int)differenceInMinutes<-15){
                                    correct=true; 
                                }else{
                                    //Phlebotomist is not available at this PSC
                                    correct=false;
                                }
                                
                            }
                      }
                      System.out.println("phlebotomist and psc is available "+correct);
                      
                    
                }else{
                    //if appointment is with a different phlebotomist then all are accepted    
                                         return true;
                }  
            }catch(ParseException e){
            
                return false;
            }
            return correct;
        }
        
}