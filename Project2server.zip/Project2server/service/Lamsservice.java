package service;
import java.util.*;
import java.lang.*;
import javax.jws.*;
import data.*;
import components.data.*;
import business.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import data.DBSingleton;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


@WebService(serviceName="RaniSoapService")
public class Lamsservice{
public Businesslayer b;
 //initialize method to load the database 
 public Lamsservice(){}

@WebMethod(operationName="Hello")
public String initialize()
{
b=new Businesslayer();
return b.initialize();
} 

@WebMethod(operationName="getAllAppointments")
public String getAllAppointments()
{
 b=new Businesslayer();
 return b.getAllAppointments();
}

@WebMethod(operationName="getAppointment")
public String getAppointment(String id)
{
b=new Businesslayer();
 return b.getAppointment(id);
}

@WebMethod(operationName="addAppointment")
public String addAppointment(String xmlstyle)
{
b=new Businesslayer();
 return b.addAppointment(xmlstyle);
}

@WebMethod(operationName="getAllPatients")
public String getAllPatients()
{
b=new Businesslayer();
return b.getAllPatients();
}

@WebMethod(operationName="getPatient")
public String getPatient(String pid)
{
b=new Businesslayer();
return b.getPatient(pid);
}
public static void main(String args[])
{
//  
Businesslayer b=new Businesslayer();
// 
String xmlstyle="<?xml version='1.0' encoding='utf-8' standalone='no'?><appointment><date>2017-12-34</date><time>11:00</time><patientId>210</patientId><physicianId>10</physicianId><pscId>510</pscId><phlebotomistId>120</phlebotomistId><labTests><test id='82088' dxcode='290.0' /><test id='86609' dxcode='307.3' /></labTests></appointment>";
// 
System.out.println(b.addAppointment(xmlstyle));
// System.out.println(b.getAppointment("790"));
// System.out.println(b.getAllAppointments());
//  System.out.println(b.getAllPatients());
// System.out.println(b.getPatient("210"));
}
}
